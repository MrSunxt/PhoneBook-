package com.sxt;

/**
 * 电话本入口类
 */
public class App {
    /**
     * 启动电话本
     */
    public static void main(String[] args) {
        App app = new App();
        app.start();
    }

    /**
     * 控制主菜单
     */
    public void start(){
        Menu menu = new Menu();
        TelNoteRegex regex = new TelNoteRegex();
        Operate operate = new Operate();
        operate.readList();
        while (true){
            menu.mainMenu();
            int item = regex.menuItemValidate(1,6);
            switch (item) {
                case 1 -> operate.addLogic();
                case 2 -> operate.searchLogic();
                case 3 -> operate.modifyLogic();
                case 4 -> operate.deleteLogic();
                case 5 -> operate.orderLogic();
                case 6 -> {
                    operate.writeList();
                    System.exit(0);
                }
            }
        }
    }
}