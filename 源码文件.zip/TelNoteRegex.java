package com.sxt;

import java.util.Scanner;

/**
 * 数据校验类
 */
public class TelNoteRegex {

    //菜单输入选项验证
    public int menuItemValidate(int min, int max){
        String regex = "[1-9]";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入对应的数字("+min+"-"+max+")：");
            String input = scanner.nextLine();
            System.out.println();
            if (input.matches(regex)){
                int inputNum = Integer.parseInt(input);
                if (inputNum >=min && inputNum <=max){
                    return inputNum;
                }else {
                    System.out.println("数字不在范围内，请重新输入！");
                }
            }else {
                System.out.println("输入错误，请重新输入！");
            }
        }
    }

    //用户输入姓名的验证
    public String nameValidate(){
        String regex = "[a-zA-Z\\s]{1,15}|[\\u4e00-\\u9fa5]{2,4}";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入姓名：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                return input;
            }else {
                System.out.println("姓名格式错误，请重新输入！");
            }
        }
    }

    //用户输入年龄的验证
    public String ageValidate(){
        String regex = "[1-9][0-9]?";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入年龄：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                return input;
            }else {
                System.out.println("年龄格式错误，请重新输入！");
            }
        }
    }

    //用户输入性别的验证
    public String sexValidate(){
        String regex = "[mfMF]";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入性别(男|m 女|f)：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                return input;
            }else {
                System.out.println("性别格式错误，请重新输入！");
            }
        }
    }

    //用户输入电话的验证
    public String telNumValidate(){
        String regex = "\\d{3,4}-\\d{7,8}|1\\d{10}";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入电话号码：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                return input;
            }else {
                System.out.println("电话格式错误，请重新输入！");
            }
        }
    }

    //用户输入地址的验证
    public String addressValidate(){
        String regex = "[\\u4e00-\\u9fa5]{1,50}|[\\w\\s]{1,50}";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入地址：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                return input;
            }else {
                System.out.println("地址格式错误，请重新输入！");
            }
        }
    }

    //输入序号验证
    public int itemValidate(int min, int max){
        String regex = "[1-9]{1,2}";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("请输入序号("+min+"-"+max+")：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                int inputNum = Integer.parseInt(input);
                if (inputNum >=min && inputNum <=max){
                    return inputNum;
                }else {
                    System.out.println("数字不在范围内，请重新输入！");
                }
            }else {
                System.out.println("输入错误，请重新输入！");
            }
        }
    }

    //判断
    public String judge(){
        String regex = "[yYnN]";
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("确认删除(Y/N)?：");
            String input = scanner.nextLine();
            if (input.matches(regex)){
                return input;
            }else {
                System.out.println("格式错误，请重新输入！");
            }
        }
    }

    /*public static void main(String[] args) {
        TelNoteRegex regex = new TelNoteRegex();
        int menuItem = regex.menuItemValidate(1,7);
        System.out.println(menuItem);
        String tel = regex.nameValidate();
        System.out.println(tel);
    }*/
}
