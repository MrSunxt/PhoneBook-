package com.sxt;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

/**
 * 核心业务类
 */
public class Operate {
    private List<Person> list;
    public Operate(){
        this.list = new ArrayList<>();
    }

//    开启前读取列表
    public void readList(){
        File file = new File("./numList.txt");
        if (!file.exists()){
            return;
        }
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream("./numList.txt"));
            if (ois!=null){
                this.list = new ArrayList<>((Collection<? extends Person>) ois.readObject());
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if (ois != null){
                    ois.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    //关闭前写入列表
    public void writeList(){
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream("./numList.txt"));
            oos.writeObject(this.list);
            oos.flush();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if (oos != null){
                    oos.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

//    用户添加记录业务逻辑控制
    public void addLogic(){
        Menu menu = new Menu();
        TelNoteRegex regex = new TelNoteRegex();
        while (true){
            menu.addMenu();
            int item = regex.menuItemValidate(1,3);
            switch (item){
                case 1:this.addOperation();break;
                case 2:this.showAll();break;
                case 3:return;
            }
        }
    }

    //用户查询记录业务逻辑控制
    public void searchLogic(){
        Menu menu = new Menu();
        TelNoteRegex regex = new TelNoteRegex();
        while (true){
            menu.searchMenu();
            int item = regex.menuItemValidate(1,7);
            switch (item){
                case 1:this.searchByName();break;
                case 2:this.searchByAge();break;
                case 3:this.searchBySex();break;
                case 4:this.searchByTelNum();break;
                case 5:this.searchByAddress();break;
                case 6:this.showAll();break;
                case 7:return;
            }
        }
    }

    //修改记录业务逻辑控制
    public void modifyLogic(){
        Menu menu = new Menu();
        TelNoteRegex regex = new TelNoteRegex();
        while (true){
            menu.modifyMenu();
            int item = regex.menuItemValidate(1,2);
            switch (item){
                case 1:this.modifyOperation();break;
                case 2:return;
            }
        }
    }

    //删除记录业务逻辑控制
    public void deleteLogic(){
        Menu menu = new Menu();
        TelNoteRegex regex = new TelNoteRegex();
        while (true){
            menu.deleteMenu();
            int item = regex.menuItemValidate(1,3);
            switch (item){
                case 1:this.deleteOperation();break;
                case 2:this.deleteAllOperation();break;
                case 3:return;
            }
        }
    }

    //排序记录业务逻辑控制
    public void orderLogic(){
        Menu menu = new Menu();
        TelNoteRegex regex = new TelNoteRegex();
        while (true){
            menu.orderMenu();
            int item = regex.menuItemValidate(1,5);
            switch (item){
                case 1:this.orderName();break;
                case 2:this.orderAge();break;
                case 3:this.orderSex();break;
                case 4:this.showAll();break;
                case 5:return;
            }
        }
    }

    //添加新记录信息
    public void addOperation(){
        TelNoteRegex regex = new TelNoteRegex();
        String name = regex.nameValidate();
        String age = regex.ageValidate();
        String sex = regex.sexValidate();
        String telNum = regex.telNumValidate();
        String address = regex.addressValidate();
        Person person = new Person(name, age, sex,telNum, address);
        this.list.add(person);
        person.setId(this.list.size());
        System.out.println("添加完成！"+"\n");
    }

    //查询全部记录
    public void showAll(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        for (Person person : this.list) {
            System.out.println(person);
        }
        System.out.println();
    }

    //按姓名查询记录
    public void searchByName(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        String name = regex.nameValidate();
        boolean flag = true;
        for (Person person : this.list) {
            if (name.equals(person.getName())) {
                System.out.println(person);
                flag = false;
            }
        }
        System.out.println();
        if (flag){
            System.out.println("无此纪录！"+"\n");
        }
    }

    //按年龄查询记录
    public void searchByAge(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        String age = regex.ageValidate();
        boolean flag = true;
        for (Person person : this.list) {
            if (age.equals(person.getAge())) {
                System.out.println(person);
                flag = false;
            }
        }
        System.out.println();
        if (flag){
            System.out.println("无此纪录！"+"\n");
        }
    }

    //按性别查询记录
    public void searchBySex(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        String sxe = regex.sexValidate();
        boolean flag = true;
        for (Person person : this.list) {
            if (sxe.equalsIgnoreCase(person.getSex())) {
                System.out.println(person);
                flag = false;
            }
        }
        System.out.println();
        if (flag){
            System.out.println("无此纪录！"+"\n");
        }
    }

    //按号码查询记录
    public void searchByTelNum(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        String telNum = regex.telNumValidate();
        boolean flag = true;
        for (Person person : this.list) {
            if (telNum.equals(person.getTelNum())) {
                System.out.println(person);
                flag = false;
            }
        }
        System.out.println();
        if (flag){
            System.out.println("无此纪录！"+"\n");
        }
    }

    //按地址查询记录
    public void searchByAddress(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        String add = regex.addressValidate();
        boolean flag = true;
        for (Person person : this.list) {
            if (add.equals(person.getAddress())) {
                System.out.println(person);
                flag = false;
            }
        }
        System.out.println();
        if (flag){
            System.out.println("无此纪录！"+"\n");
        }
    }

    //修改指定记录
    public void modifyOperation(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        Menu menu = new Menu();
        this.showAll();
        int item = regex.itemValidate(1,this.list.size());
        menu.subModifyMenu();
        int mItem = regex.menuItemValidate(1,6);
        switch (mItem) {
            case 1 -> {
                String name = regex.nameValidate();
                this.list.get(item - 1).setName(name);
                System.out.println("姓名修改成功！"+"\n");
            }
            case 2 -> {
                String age = regex.ageValidate();
                this.list.get(item - 1).setAge(age);
                System.out.println("年龄修改成功！"+"\n");
            }
            case 3 -> {
                String sex = regex.sexValidate();
                this.list.get(item - 1).setSex(sex);
                System.out.println("性别修改成功！"+"\n");
            }
            case 4 -> {
                String tel = regex.telNumValidate();
                this.list.get(item - 1).setTelNum(tel);
                System.out.println("号码修改成功！"+"\n");
            }
            case 5 -> {
                String add = regex.addressValidate();
                this.list.get(item - 1).setAddress(add);
                System.out.println("地址修改成功！"+"\n");
            }
        }
    }

    //删除指定记录
    public void deleteOperation() {
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        this.showAll();
        int item = regex.itemValidate(1,this.list.size());
        String judge = regex.judge();
        if (judge.equalsIgnoreCase("y")){
            System.out.println("联系人"+this.list.get(item-1).getName()+"已删除！"+"\n");
            this.list.remove(item-1);
            for (int i=0;i<this.list.size();i++){
                this.list.get(i).setId(i+1);
            }
        }
    }

    //删除全部记录
    public void deleteAllOperation(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        TelNoteRegex regex = new TelNoteRegex();
        String item = regex.judge();
        if (item.equalsIgnoreCase("y")){
            this.list.clear();
            System.out.println("已清空！"+"\n");
        }
    }

    //按用户姓名排序记录
    public void orderName(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        this.list.sort(new OrderByName());
        for (int i=0;i<this.list.size();i++){
            this.list.get(i).setId(i+1);
        }
        System.out.println("排序完成！"+"\n");
    }

    //按用户年龄排序记录
    public void orderAge(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        this.list.sort(new OrderByAge());
        for (int i=0;i<this.list.size();i++){
            this.list.get(i).setId(i+1);
        }
        System.out.println("排序完成！"+"\n");
    }

    //按用户性别排序记录
    public void orderSex(){
        if (this.list.size() == 0){
            System.out.println("没有任何记录！"+"\n");
            return;
        }
        this.list.sort(new OrderBySex());
        for (int i=0;i<this.list.size();i++){
            this.list.get(i).setId(i+1);
        }
        System.out.println("排序完成！");
    }

    //按姓名排序的比较器
    static class OrderByName implements Comparator<Person>{
        @Override
        public int compare(Person o1, Person o2) {
            return o1.getName().compareTo(o2.getName());
        }
    }

    //按年龄排序的比较器
    static class OrderByAge implements Comparator<Person>{
        @Override
        public int compare(Person o1, Person o2) {
            return o1.getAge().compareTo(o2.getAge());
        }
    }

    //按性别排序的比较器
    static class OrderBySex implements Comparator<Person>{
        @Override
        public int compare(Person o1, Person o2) {
            return o1.getSex().compareTo(o2.getSex());
        }
    }

}
